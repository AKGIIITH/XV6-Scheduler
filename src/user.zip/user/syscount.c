#include "./kernel/types.h"
#include "./kernel/stat.h"
#include "user.h"

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Usage: syscount <mask> command [args]\n");   // Usage: syscount <mask> command [args] 
        exit(1);
    }

    int mask = atoi(argv[1]);
    int pid = fork();

    if (pid < 0) {
        printf("fork failed\n");
        exit(1);
    }

    if (pid == 0) {
        exec(argv[2], &argv[2]);    // Execute the command and count the number of system calls in structure proc
        printf("exec %s failed\n", argv[2]);
        exit(1);
    }
    else {
        int status;
        wait(&status);
        int count = getSysCount(mask); // Get the number of system calls using getSysCount syscall
        printf("PID %d called syscall %d times.\n", pid, count);
        exit(0);
    }

    exit(0);
}