#ifndef RAND_H
#define RAND_H

int rand(void);
void do_rand(unsigned long *ctx);

#endif
